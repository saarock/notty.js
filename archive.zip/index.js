import express from "express"
const app = express();


app.listen(200, () => {
    console.log("server is running: ", 200)
})